******************************************************************************
* @file    readme.txt
* @author  MCD Application Team
* @version 3.0
* @date    05-June-2024  
* @brief   MB1367 board design files package
******************************************************************************
* COPYRIGHT(c) 2024 STMicroelectronics
*
* The Open Platform License Agreement (�Agreement�) is a binding legal contract
* between you ("You") and STMicroelectronics International N.V. (�ST�), a
* company incorporated under the laws of the Netherlands acting for the purpose
* of this Agreement through its Swiss branch 39, Chemin du Champ des Filles,
* 1228 Plan-les-Ouates, Geneva, Switzerland.
*
* By using the enclosed reference designs, schematics, PC board layouts, and
* documentation, in hardcopy or CAD tool file format (collectively, the
* �Reference Material�), You are agreeing to be bound by the terms and
* conditions of this Agreement. Do not use the Reference Material until You
* have read and agreed to this Agreement terms and conditions. The use of
* the Reference Material automatically implies the acceptance of the Agreement
* terms and conditions.
*
* The complete Open Platform License Agreement can be found on www.st.com/opla.
******************************************************************************

========================
* History
========================
* 3.0 - 05-June-2024
========================
    + Add board revision MB1367-C05.
LEDs references updated due to obsolescence (refer to the bill of materials for further details)

* 2.0 - 04-December-2020
------------------------
    + Added G491RE variant.
 
* 1.0 - 17-June-2019
------------------------
    + First official release.
	
========================
* Package content
========================
	

  
******************* (C) COPYRIGHT 2024 STMicroelectronics *****END OF FILE
