******************************************************************************
* @file    readme.txt
* @author  MCD Application Team
* @version 2.0
* @date    12-October-2024  
* @brief   MB1841 Bill Of Materials package 
******************************************************************************
* COPYRIGHT(c) 2024 STMicroelectronics
*
* The Open Platform License Agreement (�Agreement�) is a binding legal contract
* between you ("You") and STMicroelectronics International N.V. (�ST�), a
* company incorporated under the laws of the Netherlands acting for the purpose
* of this Agreement through its Swiss branch 39, Chemin du Champ des Filles,
* 1228 Plan-les-Ouates, Geneva, Switzerland.
*
* By using the enclosed reference designs, schematics, PC board layouts, and
* documentation, in hardcopy or CAD tool file format (collectively, the
* �Reference Material�), You are agreeing to be bound by the terms and
* conditions of this Agreement. Do not use the Reference Material until You
* have read and agreed to this Agreement terms and conditions. The use of
* the Reference Material automatically implies the acceptance of the Agreement
* terms and conditions.
*
* The complete Open Platform License Agreement can be found on www.st.com/opla.
******************************************************************************

========================
* 1.0 - 17-January-2023
========================
    + First official release base on MB1841-D01: NUCLEO-U545RE-Q / NUU545REQ$MR1.
========================
* 1.1 - 17-July-2024
========================
    + Add MB1841-U385RGQ-D01_BOM.xlsx(internal version).
========================
* 2.0 - 12-October-2024 
========================
    + Add MB1841-U385RGQ-E01_BOM.xlsx, official release for NUCLEO-U385RG-Q.
  
******************* (C) COPYRIGHT 2024 STMicroelectronics *****END OF FILE
