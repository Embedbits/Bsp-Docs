******************************************************************************
* @file    readme.txt
* @author  MCD Application Team
* @version 4.0
* @date    14-July-2023  
* @brief   MB1549 Bill of materials package
******************************************************************************
* COPYRIGHT(c) 2023 STMicroelectronics
*
* The Open Platform License Agreement (�Agreement�) is a binding legal contract
* between you ("You") and STMicroelectronics International N.V. (�ST�), a
* company incorporated under the laws of the Netherlands acting for the purpose
* of this Agreement through its Swiss branch 39, Chemin du Champ des Filles,
* 1228 Plan-les-Ouates, Geneva, Switzerland.
*
* By using the enclosed reference designs, schematics, PC board layouts, and
* documentation, in hardcopy or CAD tool file format (collectively, the
* �Reference Material�), You are agreeing to be bound by the terms and
* conditions of this Agreement. Do not use the Reference Material until You
* have read and agreed to this Agreement terms and conditions. The use of
* the Reference Material automatically implies the acceptance of the Agreement
* terms and conditions.
*
* The complete Open Platform License Agreement can be found on www.st.com/opla.
******************************************************************************

========================
* 1.0 - 31-May-2021
------------------------
    + First official release MB1549-C02.

========================
* 2.0 - 01-December-2021
------------------------
    + Add board revision MB1549-C03.
Update C57 and C58 capacitor for 4.7pF to 1.8pF for 32KHZ CLOAD adaptation.
Update STM32U575ZIT6QU with new embedded RSS.

========================
* 3.0 - 16-January-2023
------------------------
    + Add board revision MB1549-C04.
C57 and C58 updated from 1.8 to 6.8 pF 
32 KHz CLOAD link to STM32  32 KHz update
Update the user button  management with debounce  software (removed C84, R38) 
and update R39 to 0 R
========================
* 4.0 - 14-July-2023
------------------------
    +  Add board revision MB1549-C05.
Replace C57/C58 = 1.8pF by 6.8pF 
Several part references updated due to obsolescence (such as leds or others,
refer to the bill of materials for details)
 
******************* (C) COPYRIGHT 2023 STMicroelectronics *****END OF FILE
