******************************************************************************
* @file    readme.txt
* @author  MCD Application Team
* @version 3.0
* @date    02-February-2024   
* @brief   MB989 Bill of materials package
******************************************************************************
* COPYRIGHT(c) 2024 STMicroelectronics
*
* The Open Platform License Agreement (�Agreement�) is a binding legal contract
* between you ("You") and STMicroelectronics International N.V. (�ST�), a
* company incorporated under the laws of the Netherlands acting for the purpose
* of this Agreement through its Swiss branch 39, Chemin du Champ des Filles,
* 1228 Plan-les-Ouates, Geneva, Switzerland.
*
* By using the enclosed reference designs, schematics, PC board layouts, and
* documentation, in hardcopy or CAD tool file format (collectively, the
* �Reference Material�), You are agreeing to be bound by the terms and
* conditions of this Agreement. Do not use the Reference Material until You
* have read and agreed to this Agreement terms and conditions. The use of
* the Reference Material automatically implies the acceptance of the Agreement
* terms and conditions.
*
* The complete Open Platform License Agreement can be found on www.st.com/opla.
******************************************************************************

========================
* History
========================

* 3.0 - 02-February-2024
------------------------
    + Add board revision MB989-C02.
Several part references updated due to obsolescence 
(such as Capacitors, refer to the bill of materials for details)

* 2.0 - 19-March-2019
------------------------
    + Added revision C01.
Split the power supplies VDD and VCI to be able to support on VDD the 3V3 and 1V8 voltage domains
Add R25 to offer the possibility to connect VDD and VCI togeteher (to back to original design).
 
* 1.0 - 17-January-2017
------------------------
    + First official release.
	
========================
* Package content
========================
	

  
******************* (C) COPYRIGHT 2024 STMicroelectronics *****END OF FILE
