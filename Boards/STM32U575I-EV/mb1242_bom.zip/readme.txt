******************************************************************************
* @file    readme.txt
* @author  MCD Application Team
* @version 1.0
* @date    20-August-2020  
* @brief   MB1242 BOM files package
******************************************************************************
* COPYRIGHT(c) 2020 STMicroelectronics
*
* The Open Platform License Agreement (�Agreement�) is a binding legal contract
* between you ("You") and STMicroelectronics International N.V. (�ST�), a
* company incorporated under the laws of the Netherlands acting for the purpose
* of this Agreement through its Swiss branch 39, Chemin du Champ des Filles,
* 1228 Plan-les-Ouates, Geneva, Switzerland.
*
* By using the enclosed reference designs, schematics, PC board layouts, and
* documentation, in hardcopy or CAD tool file format (collectively, the
* �Reference Material�), You are agreeing to be bound by the terms and
* conditions of this Agreement. Do not use the Reference Material until You
* have read and agreed to this Agreement terms and conditions. The use of
* the Reference Material automatically implies the acceptance of the Agreement
* terms and conditions.
*
* The complete Open Platform License Agreement can be found on www.st.com/opla.
******************************************************************************

========================
* 1.0 - 20-August-2020
------------------------
    + First official release for MB1242 with APMEMORY APS6408L.

  
******************* (C) COPYRIGHT 2020 STMicroelectronics *****END OF FILE
