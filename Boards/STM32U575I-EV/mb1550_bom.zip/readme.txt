******************************************************************************
* @file    readme.txt
* @author  MCD Application Team
* @version 2.0
* @date    02-February-2024  
* @brief   MB1550 Bill of materials package
******************************************************************************
* COPYRIGHT(c) 2024 STMicroelectronics
*
* The Open Platform License Agreement (�Agreement�) is a binding legal contract
* between you ("You") and STMicroelectronics International N.V. (�ST�), a
* company incorporated under the laws of the Netherlands acting for the purpose
* of this Agreement through its Swiss branch 39, Chemin du Champ des Filles,
* 1228 Plan-les-Ouates, Geneva, Switzerland.
*
* By using the enclosed reference designs, schematics, PC board layouts, and
* documentation, in hardcopy or CAD tool file format (collectively, the
* �Reference Material�), You are agreeing to be bound by the terms and
* conditions of this Agreement. Do not use the Reference Material until You
* have read and agreed to this Agreement terms and conditions. The use of
* the Reference Material automatically implies the acceptance of the Agreement
* terms and conditions.
*
* The complete Open Platform License Agreement can be found on www.st.com/opla.
******************************************************************************

========================
* 2.0 - 02-February-2024
========================
    + Add board revision MB1550-C03.
C30 and C31 capacitors updated from 1.8 pF to 6.8 pF 
Several part references updated due to obsolescence (such as leds or others,
refer to the bill of materials for details)
========================
* 1.0 - 06-July-2021
========================
    + First official release.
  
******************* (C) COPYRIGHT 2024 STMicroelectronics *****END OF FILE
   
 
