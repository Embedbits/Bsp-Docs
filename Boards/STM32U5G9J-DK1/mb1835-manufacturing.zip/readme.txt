******************************************************************************
* @file    readme.txt
* @author  MCD Application Team
* @version 1.1
* @date    20-March-2023
* @brief   MB1835 Manufacturing files package
******************************************************************************
* COPYRIGHT(c) 2023 STMicroelectronics
*
* The Open Platform License Agreement (�Agreement�) is a binding legal contract
* between you ("You") and STMicroelectronics International N.V. (�ST�), a
* company incorporated under the laws of the Netherlands acting for the purpose
* of this Agreement through its Swiss branch 39, Chemin du Champ des Filles,
* 1228 Plan-les-Ouates, Geneva, Switzerland.
*
* By using the enclosed reference designs, schematics, PC board layouts, and
* documentation, in hardcopy or CAD tool file format (collectively, the
* �Reference Material�), You are agreeing to be bound by the terms and
* conditions of this Agreement. Do not use the Reference Material until You
* have read and agreed to this Agreement terms and conditions. The use of
* the Reference Material automatically implies the acceptance of the Agreement
* terms and conditions.
*
* The complete Open Platform License Agreement can be found on www.st.com/opla.
******************************************************************************

========================
* History
========================

* 1.1 - 20-March-2023
------------------------
    + Update MB1835B_dimensions.pdf according to M3/M4 Layers, update MB1835B_Gerber.pdf without variant name, re-generate all relevant files with no variation


* 1.0 - 14-February-2023
------------------------
    + First official release.
	


  
******************* (C) COPYRIGHT 2023 STMicroelectronics *****END OF FILE
