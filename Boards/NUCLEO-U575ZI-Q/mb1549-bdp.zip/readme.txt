******************************************************************************
* @file    readme.txt
* @author  MCD Application Team
* @version 3.1
* @date    06-July-2023  
* @brief   MB1549 board design files package
******************************************************************************
* COPYRIGHT(c) 2023 STMicroelectronics
*
* The Open Platform License Agreement (�Agreement�) is a binding legal contract
* between you ("You") and STMicroelectronics International N.V. (�ST�), a
* company incorporated under the laws of the Netherlands acting for the purpose
* of this Agreement through its Swiss branch 39, Chemin du Champ des Filles,
* 1228 Plan-les-Ouates, Geneva, Switzerland.
*
* By using the enclosed reference designs, schematics, PC board layouts, and
* documentation, in hardcopy or CAD tool file format (collectively, the
* �Reference Material�), You are agreeing to be bound by the terms and
* conditions of this Agreement. Do not use the Reference Material until You
* have read and agreed to this Agreement terms and conditions. The use of
* the Reference Material automatically implies the acceptance of the Agreement
* terms and conditions.
*
* The complete Open Platform License Agreement can be found on www.st.com/opla.
******************************************************************************


* 1.0 - 31-May-2021
------------------------
    + First official release for MB1549-U575ZIQ-C02.

========================
* 2.0 - 01-December-2021
------------------------
    + New release for MB1549-U575ZIQ-C03.
Update C57 and C58 capacitor for 4.7pF to 1.8pF for 32KHZ CLOAD adaptation.
Update STM32U575ZIT6QU with new embedded RSS.

========================
* 3.0 - 16-January-2023
------------------------
    + Add official release MB1549-C04 revision.

========================
* 3.1 - 06-July-2023
------------------------
    + Removed old revision. Official release MB1549C revision.
========================
* 4.0 - 14-July-2023
------------------------
    + Add official revision MB1549-C05 
Several part references updated due to obsolescence (such as LEDs or others, refer to the bill of materials for details)
Update the user button management with debounce software (added C84, R38) and update R39 to 330R 

  
******************* (C) COPYRIGHT 2023 STMicroelectronics *****END OF FILE
