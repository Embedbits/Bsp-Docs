******************************************************************************
* @file    readme.txt
* @author  MCD Application Team
* @version 2.1
* @date    18-Oct-2024 
* @brief   MB1860 board design project files package
******************************************************************************
* COPYRIGHT(c) 2023 STMicroelectronics
*
* The Open Platform License Agreement (�Agreement�) is a binding legal contract
* between you ("You") and STMicroelectronics International N.V. (�ST�), a
* company incorporated under the laws of the Netherlands acting for the purpose
* of this Agreement through its Swiss branch 39, Chemin du Champ des Filles,
* 1228 Plan-les-Ouates, Geneva, Switzerland.
*
* By using the enclosed reference designs, schematics, PC board layouts, and
* documentation, in hardcopy or CAD tool file format (collectively, the
* �Reference Material�), You are agreeing to be bound by the terms and
* conditions of this Agreement. Do not use the Reference Material until You
* have read and agreed to this Agreement terms and conditions. The use of
* the Reference Material automatically implies the acceptance of the Agreement
* terms and conditions.
*
* The complete Open Platform License Agreement can be found on www.st.com/opla.
******************************************************************************

========================
* History
========================

* 2.1 - 18-Oct-2024 
------------------------
    + Remove useless files in the project file.


* 2.0 - 13-Dec-2023 
------------------------
    + Add MB1860-B01: Backlight control signal default LOW, to be controlled by MCU.


* 1.0 - 07-Oct-2023 
------------------------
    + First official release.
	
  
******************* (C) COPYRIGHT 2024 STMicroelectronics *****END OF FILE
